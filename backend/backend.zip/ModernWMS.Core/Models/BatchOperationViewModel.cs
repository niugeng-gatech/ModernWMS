﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModernWMS.Core.Models
{
    public class BatchOperationViewModel
    {
        public List<int> id_list { get; set; } = new List<int>();
    }
}
