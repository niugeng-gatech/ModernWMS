﻿
namespace ModernWMS.Core.DI
{
    public interface IDependency
    {
    }
}
